##### material properties:
1. change across boumndaries, dependent upon the temperature and pressure, may be influenced by shera stresses or strains.
2. here， we concentrate on the **stress, composition and temperature**.
3. appearing in the weak form are naturally invorporated into the quadrature approximation without needing to perform any interpolation. (inhent FEM characterial)
4. 



